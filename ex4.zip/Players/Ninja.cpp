#include "Ninja.h"

void Ninja::addCoins(int additionalCoins) { 
    m_coins += 2 * additionalCoins; 
}